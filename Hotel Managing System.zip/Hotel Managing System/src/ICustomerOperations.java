
public interface ICustomerOperations {
public void insertACustomer(Customer cu);
public void showAllCustomer(Customer cu);
public void searchACustomer(Customer cu);
public void deleteACustomer(Customer cu);
}
