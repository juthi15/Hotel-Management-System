
public interface IEmployeeOperations {
public void insertAnEmployee(Employee emp);
public void showAllEmployee(Employee emp);
public void searchAnEmployee(Employee emp);
public void deleteAnEmployee(Employee emp);
}
